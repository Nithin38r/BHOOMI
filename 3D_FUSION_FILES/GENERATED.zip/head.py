"""AgriMesh soil node: above-ground head enclosure (body + lid + electronics sled).
All dimensions in mm. z = 0 is the bottom of the body (the PVC pipe enters from below).
Run: python3 head.py  -> STEP + STL files in ./out"""
import math, os, time
from csg import *

# ------------------------------------------------------------------ parameters
P = dict(
    pipe_od=75.0, socket_clear=0.6, socket_depth=40.0,   # PVC pipe enters from below
    body_od=92.0, wall=3.0, floor=4.0, cavity_h=128.0,     # electronics bay
    rim_in_r=40.0,                                         # inner radius of the top sealing rim
    panel_d=90.0, panel_t=2.6,                             # round solar panel on top
    lid_od=112.0, lid_plate=4.4, skirt=10.0,
    oring_d=2.0,                                           # O-ring cord in the lid groove
    seg=96,
)
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "out")
os.makedirs(OUT, exist_ok=True)

R = P["body_od"]/2                     # 46
SR = (P["pipe_od"] + P["socket_clear"])/2   # 37.8 socket radius
Z_FLOOR0 = P["socket_depth"]           # 40
Z_FLOOR1 = Z_FLOOR0 + P["floor"]       # 44
Z_TOP = Z_FLOOR1 + P["cavity_h"]       # 172
RI = R - P["wall"]                     # 43 cavity radius
RIM = P["rim_in_r"]                    # 40
LUG_ANG = [90, 210, 330]
LUG_R = 50.0                           # screw circle radius (outside the O-ring)

def build_body():
    seg = P["seg"]
    prof = [(0.0, Z_FLOOR0), (SR, Z_FLOOR0), (SR, 1.5), (SR + 1.5, 0.0), (R - 1.0, 0.0), (R, 1.0),
            (R, Z_TOP), (RIM, Z_TOP), (RIM, Z_TOP - 6), (RI, Z_TOP - 9), (RI, Z_FLOOR1), (0.0, Z_FLOOR1)]
    body = revolve(prof, seg)
    adds = []
    # three external screw lugs with 45-degree undersides (print without supports)
    for a in LUG_ANG:
        adds.append(polar_hull(a, [(R-2, -6, Z_TOP), (LUG_R+3, -6, Z_TOP), (LUG_R+3, -6, Z_TOP-12), (R-2, -6, Z_TOP-21),
                                   (R-2, 6, Z_TOP), (LUG_R+3, 6, Z_TOP), (LUG_R+3, 6, Z_TOP-12), (R-2, 6, Z_TOP-21)]))
    # sled rails: two ribs each side form a 2.8 mm slot on the x axis
    for sx in (1, -1):
        for y0, y1 in ((1.4, 3.4), (-3.4, -1.4)):
            x0, x1 = (36.0, RI + 1.0) if sx > 0 else (-(RI + 1.0), -36.0)
            adds.append(box((x0, y0, Z_FLOOR1), (x1, y1, Z_TOP - 14)))
    # antenna holder: flat round pad for an SMA bulkhead (antenna points up via a right-angle SMA)
    adds.append(radial_cyl(30, Z_TOP - 22, RI + 1, R + 3.5, 8.5))
    # air-sensor (SHT31) cable gland pad
    adds.append(radial_cyl(150, Z_TOP - 32, RI + 1, R + 3, 10.5))
    # breather vent pad (membrane vent keeps out water, lets humidity out) + 45-degree rain hood
    adds.append(radial_cyl(250, 70, RI + 1, R + 3, 10.0))
    adds.append(polar_hull(250, [(R-2, -12, 96), (R+11, -12, 96), (R+11, -12, 93), (R-2, -12, 80),
                                 (R-2, 12, 96), (R+11, 12, 96), (R+11, 12, 93), (R-2, 12, 80)]))
    # status-LED boss
    adds.append(radial_cyl(60, 120, RI + 1, R + 1.5, 5.0))
    for a in adds: body = body.union(a)
    cuts = []
    for a in (90, 270): cuts.append(radial_cyl(a, 20, SR - 2, R + 2, 2.25, 24))         # M4 into the PVC pipe
    for a in (30, 150, 270): cuts.append(axial_cyl(a, 24, Z_FLOOR0 - 1, Z_FLOOR1 + 1, 6.25))  # 3 x PG7 floor glands
    for a in LUG_ANG: cuts.append(axial_cyl(a, LUG_R, Z_TOP - 9, Z_TOP + 1, 2.1, 24))   # M3 heat-set inserts
    cuts.append(radial_cyl(30, Z_TOP - 22, RI - 2, R + 5, 3.3, 32))                      # SMA bulkhead 6.6
    cuts.append(radial_cyl(150, Z_TOP - 32, RI - 2, R + 5, 6.25))                        # PG7 gland 12.5
    cuts.append(radial_cyl(250, 70, RI - 2, R + 5, 6.1))                                 # M12 vent 12.2
    cuts.append(radial_cyl(60, 120, RI - 2, R + 3, 2.6, 24))                             # 5 mm LED
    for c in cuts: body = body.subtract(c)
    return body

def build_lid():
    seg = P["seg"]; z0 = Z_TOP; zt = z0 + P["lid_plate"] + P["panel_t"]
    LR = P["lid_od"]/2; sk_in = LUG_R + 3.5
    g0, g1 = 43 - (P["oring_d"]*1.2)/2, 43 + (P["oring_d"]*1.2)/2       # groove centred on the rim
    pr = P["panel_d"]/2 + 0.5
    prof = [(0.0, z0), (g0, z0), (g0, z0 + P["oring_d"]*.8), (g1, z0 + P["oring_d"]*.8), (g1, z0),
            (sk_in, z0), (sk_in, z0 - P["skirt"]), (LR, z0 - P["skirt"]), (LR, zt - 1), (LR - 1, zt),
            (pr, zt), (pr, zt - P["panel_t"]), (0.0, zt - P["panel_t"])]
    lid = revolve(prof, seg)
    cuts = []
    for a in LUG_ANG:
        cuts.append(axial_cyl(a, LUG_R, z0 - 1, zt + 1, 1.7, 24))          # M3 clearance
        cuts.append(axial_cyl(a, LUG_R, zt - 3.4, zt + 1, 3.3, 32))        # counterbore for the head
    cuts.append(axial_cyl(0, 0, z0 - 1, zt + 1, 3.0, 32))                   # panel cable, centre
    cuts.append(polar_hull(180, [(pr - 3, -4, zt - P["panel_t"]), (pr + 2.5, -4, zt - P["panel_t"]), (pr - 3, 4, zt - P["panel_t"]), (pr + 2.5, 4, zt - P["panel_t"]),
                                 (pr - 3, -4, zt + 1), (pr + 2.5, -4, zt + 1), (pr - 3, 4, zt + 1), (pr + 2.5, 4, zt + 1)]))   # pry notch
    for a in (60, 300):                                                       # rain drains from the pocket
        cuts.append(polar_hull(a, [(pr - 1, -1.5, zt - 1.2), (LR + 1, -1.5, zt - 1.2), (pr - 1, 1.5, zt - 1.2), (LR + 1, 1.5, zt - 1.2),
                                   (pr - 1, -1.5, zt + 1), (LR + 1, -1.5, zt + 1), (pr - 1, 1.5, zt + 1), (LR + 1, 1.5, zt + 1)]))
    for c in cuts: lid = lid.subtract(c)
    return lid

def build_sled():
    z0, z1, hw, t = Z_FLOOR1 + 0.5, Z_TOP - 15, 39.0, 2.4
    sled = box((-hw, -t/2, z0), (hw, t/2, z1))
    adds = []
    # ESP32 standoffs on the +y face (board ~52 x 28, long side vertical)
    for x in (-11.5, 11.5):
        for z in (z1 - 52, z1 - 6):
            adds.append(cylinder((x, t/2 - .2, z), (x, t/2 + 5, z), 2.6, 24))
    # LoRa (RFM95W breakout) standoffs
    for x in (-10, 10):
        for z in (z0 + 14, z0 + 34):
            adds.append(cylinder((x, t/2 - .2, z), (x, t/2 + 4, z), 2.4, 24))
    # 18650 cradle on the -y face (cell stands vertically, held by two cable ties)
    adds.append(box((-11, -12, z0 + 4), (11, -t/2 + .2, z0 + 74)))
    for a in adds: sled = sled.union(a)
    cuts = [cylinder((0, -12.6, z0 + 2), (0, -12.6, z0 + 76), 9.6, 48)]
    for x in (-11.5, 11.5):
        for z in (z1 - 52, z1 - 6): cuts.append(cylinder((x, -t, z), (x, t/2 + 6, z), 1.1, 16))
    for x in (-10, 10):
        for z in (z0 + 14, z0 + 34): cuts.append(cylinder((x, -t, z), (x, t/2 + 5, z), 1.1, 16))
    for x in (-15.5, 15.5):                                                   # cable-tie slots
        for z in (z0 + 15, z0 + 60, z1 - 30, z1 - 12):
            cuts.append(box((x - 1, -t, z - 2.5), (x + 1, t, z + 2.5)))
    cuts.append(box((24, -t, z1 - 12), (34, t, z1 - 4)))                     # finger slot to pull the sled out
    cuts.append(box((-34, -t, z0 + 40), (-24, t, z0 + 52)))                  # cable pass-through
    for c in cuts: sled = sled.subtract(c)
    return sled

if __name__ == "__main__":
    report = []
    parts = {}
    for name, fn in (("body", build_body), ("lid", build_lid), ("sled", build_sled)):
        t = time.time(); s = fn(); m = Mesh(s); e, bad = m.edge_report()
        parts[name] = m
        report.append(f"{name}: {len(m.F)} polys, {len(m.merged_faces())} faces, open/bad edges {bad}, volume {m.volume()/1000:.1f} cm3, {time.time()-t:.1f}s")
        print(report[-1], flush=True)
    names = {"body": "P1_head_body", "lid": "P2_head_lid_round_panel", "sled": "P4_electronics_sled"}
    for k, m in parts.items():
        write_step([(names[k], m)], os.path.join(OUT, f"AgriMesh_{names[k]}.step"), f"AgriMesh {names[k]}")
        write_stl(m, os.path.join(OUT, f"AgriMesh_{names[k]}.stl"), names[k])
    write_step([(names[k], m) for k, m in parts.items()], os.path.join(OUT, "AgriMesh_head_assembly.step"), "AgriMesh head assembly")
    print("written to", OUT)
