"""Small BSP-tree CSG kernel (port of the csg.js algorithm) with iterative traversal,
plus mesh cleanup (vertex welding, T-junction repair, coplanar face merging),
watertightness check, STL writer and an AP214 STEP writer (planar B-rep). Units: mm."""
import math, struct, datetime
import numpy as np
from scipy.spatial import cKDTree, ConvexHull

EPS = 1e-6
COPLANAR, FRONT, BACK, SPANNING = 0, 1, 2, 3


def sub(a, b): return (a[0]-b[0], a[1]-b[1], a[2]-b[2])
def add(a, b): return (a[0]+b[0], a[1]+b[1], a[2]+b[2])
def mul(a, s): return (a[0]*s, a[1]*s, a[2]*s)
def dot(a, b): return a[0]*b[0] + a[1]*b[1] + a[2]*b[2]
def cross(a, b): return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
def norm(a):
    l = math.sqrt(dot(a, a)); return (a[0]/l, a[1]/l, a[2]/l)
def lerp(a, b, t): return (a[0]+(b[0]-a[0])*t, a[1]+(b[1]-a[1])*t, a[2]+(b[2]-a[2])*t)


class Plane:
    __slots__ = ("n", "w")
    def __init__(self, n, w): self.n, self.w = n, w
    @staticmethod
    def from_poly(vs):
        # Newell's method: robust normal for any planar polygon
        nx = ny = nz = 0.0
        for i in range(len(vs)):
            a, b = vs[i], vs[(i+1) % len(vs)]
            nx += (a[1]-b[1])*(a[2]+b[2]); ny += (a[2]-b[2])*(a[0]+b[0]); nz += (a[0]-b[0])*(a[1]+b[1])
        n = norm((nx, ny, nz))
        c = mul(tuple(map(sum, zip(*vs))), 1.0/len(vs))
        return Plane(n, dot(n, c))
    def flipped(self): return Plane((-self.n[0], -self.n[1], -self.n[2]), -self.w)

    def split(self, poly, cf, cb, f, b):
        n, w = self.n, self.w
        types = []; ptype = 0
        for v in poly.v:
            t = n[0]*v[0] + n[1]*v[1] + n[2]*v[2] - w
            ty = BACK if t < -EPS else (FRONT if t > EPS else COPLANAR)
            ptype |= ty; types.append(ty)
        if ptype == COPLANAR:
            (cf if dot(n, poly.p.n) > 0 else cb).append(poly)
        elif ptype == FRONT: f.append(poly)
        elif ptype == BACK: b.append(poly)
        else:
            fv, bv = [], []
            vs = poly.v; m = len(vs)
            for i in range(m):
                j = (i+1) % m; ti, tj = types[i], types[j]; vi, vj = vs[i], vs[j]
                if ti != BACK: fv.append(vi)
                if ti != FRONT: bv.append(vi)
                if (ti | tj) == SPANNING:
                    d = sub(vj, vi)
                    t = (w - dot(n, vi)) / dot(n, d)
                    v = lerp(vi, vj, t); fv.append(v); bv.append(v)
            if len(fv) >= 3: f.append(Poly(fv, poly.p))
            if len(bv) >= 3: b.append(Poly(bv, poly.p))


class Poly:
    __slots__ = ("v", "p")
    def __init__(self, v, p=None):
        self.v = v; self.p = p if p is not None else Plane.from_poly(v)
    def flipped(self): return Poly(self.v[::-1], self.p.flipped())


class Node:
    __slots__ = ("plane", "front", "back", "polys")
    def __init__(self, polys=None):
        self.plane = None; self.front = None; self.back = None; self.polys = []
        if polys: self.build(polys)

    def nodes(self):
        out, st = [], [self]
        while st:
            n = st.pop(); out.append(n)
            if n.front: st.append(n.front)
            if n.back: st.append(n.back)
        return out

    def invert(self):
        for n in self.nodes():
            n.polys = [p.flipped() for p in n.polys]
            if n.plane: n.plane = n.plane.flipped()
            n.front, n.back = n.back, n.front

    def clip_polys(self, polys):
        res, st = [], [(self, polys)]
        while st:
            node, ps = st.pop()
            if node.plane is None: res.extend(ps); continue
            f, b = [], []
            for p in ps: node.plane.split(p, f, b, f, b)
            if node.front: st.append((node.front, f))
            else: res.extend(f)
            if node.back: st.append((node.back, b))
        return res

    def clip_to(self, bsp):
        for n in self.nodes(): n.polys = bsp.clip_polys(n.polys)

    def all_polys(self):
        out = []
        for n in self.nodes(): out.extend(n.polys)
        return out

    def build(self, polys):
        st = [(self, polys)]
        while st:
            node, ps = st.pop()
            if not ps: continue
            if node.plane is None: node.plane = ps[0].p
            f, b = [], []
            for p in ps: node.plane.split(p, node.polys, node.polys, f, b)
            if f:
                if node.front is None: node.front = Node()
                st.append((node.front, f))
            if b:
                if node.back is None: node.back = Node()
                st.append((node.back, b))


class Solid:
    def __init__(self, polys): self.polys = polys
    def bbox(self):
        a = np.array([v for p in self.polys for v in p.v]); return a.min(0), a.max(0)
    def _overlap(self, o):
        a0, a1 = self.bbox(); b0, b1 = o.bbox()
        return bool(np.all(a0 <= b1 + 1e-3) and np.all(b0 <= a1 + 1e-3))
    def union(self, o):
        if not self._overlap(o): return Solid(self.polys + o.polys)
        a, b = Node(list(self.polys)), Node(list(o.polys))
        a.clip_to(b); b.clip_to(a); b.invert(); b.clip_to(a); b.invert(); a.build(b.all_polys())
        return Solid(a.all_polys())
    def subtract(self, o):
        if not self._overlap(o): return Solid(list(self.polys))
        a, b = Node(list(self.polys)), Node(list(o.polys))
        a.invert(); a.clip_to(b); b.clip_to(a); b.invert(); b.clip_to(a); b.invert(); a.build(b.all_polys()); a.invert()
        return Solid(a.all_polys())
    def transformed(self, M, t=(0, 0, 0)):
        M = np.asarray(M, float)
        def tf(v):
            x = M @ np.array(v); return (x[0]+t[0], x[1]+t[1], x[2]+t[2])
        return Solid([Poly([tf(v) for v in p.v]) for p in self.polys])
    def rotz(self, deg, t=(0, 0, 0)):
        c, s = math.cos(math.radians(deg)), math.sin(math.radians(deg))
        return self.transformed([[c, -s, 0], [s, c, 0], [0, 0, 1]], t)
    def moved(self, t): return self.transformed(np.eye(3), t)


def union_all(solids):
    s = solids[0]
    for o in solids[1:]: s = s.union(o)
    return s

# ------------------------------------------------------------------ primitives

def _orient_out(polys):
    """Flip all faces if the signed volume is negative."""
    vol = 0.0
    for p in polys:
        a = p.v[0]
        for i in range(1, len(p.v)-1):
            vol += dot(a, cross(p.v[i], p.v[i+1]))
    return polys if vol > 0 else [q.flipped() for q in polys]

def revolve(profile, seg=96):
    """Revolve a closed (r, z) profile around the z axis. r = 0 points collapse onto the axis."""
    polys = []
    ang = [2*math.pi*i/seg for i in range(seg)]
    def P(r, z, i): return (0.0, 0.0, z) if r == 0 else (r*math.cos(ang[i % seg]), r*math.sin(ang[i % seg]), z)
    m = len(profile)
    for k in range(m):
        (r0, z0), (r1, z1) = profile[k], profile[(k+1) % m]
        for i in range(seg):
            q = [P(r0, z0, i), P(r1, z1, i), P(r1, z1, i+1), P(r0, z0, i+1)]
            ded = []
            for v in q:
                if not ded or max(abs(v[0]-ded[-1][0]), abs(v[1]-ded[-1][1]), abs(v[2]-ded[-1][2])) > 1e-9: ded.append(v)
            if len(ded) > 1 and max(abs(ded[0][j]-ded[-1][j]) for j in range(3)) < 1e-9: ded.pop()
            if len(ded) >= 3: polys.append(Poly(ded))
    return Solid(_orient_out(polys))

def cylinder(p0, p1, r, seg=48):
    p0, p1 = tuple(map(float, p0)), tuple(map(float, p1))
    ax = norm(sub(p1, p0))
    tmp = (1, 0, 0) if abs(ax[0]) < .9 else (0, 1, 0)
    u = norm(cross(ax, tmp)); v = cross(ax, u)
    ring0, ring1 = [], []
    for i in range(seg):
        a = 2*math.pi*i/seg
        d = add(mul(u, r*math.cos(a)), mul(v, r*math.sin(a)))
        ring0.append(add(p0, d)); ring1.append(add(p1, d))
    polys = [Poly(ring0[::-1]), Poly(ring1)]
    for i in range(seg):
        j = (i+1) % seg
        polys.append(Poly([ring0[i], ring0[j], ring1[j], ring1[i]]))
    return Solid(_orient_out(polys))

def hull(points):
    pts = np.asarray(points, float); h = ConvexHull(pts)
    c = pts.mean(0); polys = []
    for simp, eq in zip(h.simplices, h.equations):
        tri = [tuple(pts[i]) for i in simp]
        n = np.cross(np.subtract(tri[1], tri[0]), np.subtract(tri[2], tri[0]))
        if np.dot(n, eq[:3]) < 0: tri = tri[::-1]
        polys.append(Poly(tri))
    return Solid(polys)

def box(lo, hi):
    (x0, y0, z0), (x1, y1, z1) = lo, hi
    return hull([(x, y, z) for x in (x0, x1) for y in (y0, y1) for z in (z0, z1)])

def radial_cyl(deg, z, r0, r1, rad, seg=40):
    a = math.radians(deg); c, s = math.cos(a), math.sin(a)
    return cylinder((r0*c, r0*s, z), (r1*c, r1*s, z), rad, seg)

def axial_cyl(deg, rpos, z0, z1, rad, seg=40):
    a = math.radians(deg); x, y = rpos*math.cos(a), rpos*math.sin(a)
    return cylinder((x, y, z0), (x, y, z1), rad, seg)

def polar_hull(deg, pts_rtz):
    """Convex hull of points given as (radial, tangential, z) in a frame rotated by deg."""
    a = math.radians(deg); c, s = math.cos(a), math.sin(a)
    return hull([(r*c - t*s, r*s + t*c, z) for r, t, z in pts_rtz])

# ------------------------------------------------------------------ mesh cleanup

class Mesh:
    """Indexed polygon mesh with welded vertices and repaired T-junctions."""
    def __init__(self, solid, weld=1e-4):
        allv = np.array([v for p in solid.polys for v in p.v])
        tree = cKDTree(allv)
        pairs = tree.query_pairs(weld, output_type="ndarray")
        parent = np.arange(len(allv))
        def find(i):
            while parent[i] != i:
                parent[i] = parent[parent[i]]; i = parent[i]
            return i
        for i, j in pairs:
            ri, rj = find(i), find(j)
            if ri != rj: parent[max(ri, rj)] = min(ri, rj)
        roots = np.array([find(i) for i in range(len(allv))])
        uniq, inv = np.unique(roots, return_inverse=True)
        self.V = allv[uniq]
        faces, k = [], 0
        for p in solid.polys:
            idx = list(inv[k:k+len(p.v)]); k += len(p.v)
            clean = []
            for i in idx:
                if not clean or clean[-1] != i: clean.append(i)
            while len(clean) > 1 and clean[0] == clean[-1]: clean.pop()
            if len(clean) >= 3: faces.append((clean, p.p.n))
        self.F = faces
        self._fix_tjunctions()
        self._drop_degenerate()
        self._repair_open_edges()

    def _bad_edges(self):
        from collections import Counter
        c = Counter()
        for f, _ in self.F:
            for i in range(len(f)): c[(f[i], f[(i+1) % len(f)])] += 1
        return [(a, b) for (a, b), k in c.items() if k != 1 or c.get((b, a), 0) != 1]

    def _repair_open_edges(self, tol=0.02, rounds=6):
        """Merge near-duplicate vertices that sit on open edges (BSP round-off), then re-clean."""
        for _ in range(rounds):
            bad = self._bad_edges()
            if not bad: return
            vs = sorted({v for e in bad for v in e})
            pts = self.V[vs]; tree = cKDTree(pts)
            remap = {}
            for i, j in tree.query_pairs(tol):
                a, b = vs[i], vs[j]
                ra, rb = remap.get(a, a), remap.get(b, b)
                if ra != rb: remap[max(ra, rb)] = min(ra, rb)
            if not remap: return
            def R(i):
                while i in remap: i = remap[i]
                return i
            newF = []
            for f, n in self.F:
                g = []
                for i in f:
                    i = R(i)
                    if not g or g[-1] != i: g.append(i)
                while len(g) > 1 and g[0] == g[-1]: g.pop()
                if len(g) >= 3: newF.append((g, n))
            self.F = newF
            self._fix_tjunctions(); self._drop_degenerate()

    def _fix_tjunctions(self):
        V = self.V; tree = cKDTree(V)
        newF = []
        for f, n in self.F:
            out = []
            m = len(f)
            for i in range(m):
                a, b = f[i], f[(i+1) % m]; out.append(a)
                pa, pb = V[a], V[b]; d = pb - pa; L = np.linalg.norm(d)
                if L < 1e-9: continue
                cand = tree.query_ball_point((pa+pb)/2, L/2 + 1e-4)
                ins = []
                for c in cand:
                    if c == a or c == b: continue
                    t = np.dot(V[c]-pa, d)/(L*L)
                    if t <= 1e-7 or t >= 1-1e-7: continue
                    if np.linalg.norm(pa + t*d - V[c]) < 5e-5: ins.append((t, c))
                ins.sort(); out.extend(c for _, c in ins)
            newF.append((out, n))
        self.F = newF

    def _drop_degenerate(self):
        V = self.V; keep = []
        for f, n in self.F:
            pts = V[f]
            area = 0.5*np.linalg.norm(sum(np.cross(pts[i], pts[(i+1) % len(pts)]) for i in range(len(pts))))
            if area > 1e-8: keep.append((f, n))
        self.F = keep

    def edge_report(self):
        from collections import Counter
        c = Counter()
        for f, _ in self.F:
            for i in range(len(f)): c[(f[i], f[(i+1) % len(f)])] += 1
        bad = 0
        for (a, b), k in c.items():
            if k != 1 or c.get((b, a), 0) != 1: bad += 1
        return len(c), bad

    def triangles(self):
        V = self.V; tris = []
        for f, n in self.F:
            tris.extend(_triangulate(V, f, np.asarray(n)))
        return tris

    def volume(self):
        V = self.V; vol = 0.0
        for a, b, c in self.triangles(): vol += np.dot(V[a], np.cross(V[b], V[c]))
        return vol/6.0

    def merged_faces(self):
        """Group coplanar, edge-connected polygons into faces with outer and inner loops."""
        V = self.V
        keyed = {}
        for idx, (f, n) in enumerate(self.F):
            n = np.asarray(n); w = float(np.dot(n, V[f[0]]))
            key = (round(n[0], 5), round(n[1], 5), round(n[2], 5), round(w, 3))
            keyed.setdefault(key, []).append(idx)
        faces = []
        for key, ids in keyed.items():
            # connected components via shared edges
            edge_owner = {}
            for i in ids:
                f = self.F[i][0]
                for k in range(len(f)): edge_owner.setdefault(frozenset((f[k], f[(k+1) % len(f)])), []).append(i)
            parent = {i: i for i in ids}
            def find(i):
                while parent[i] != i: parent[i] = parent[parent[i]]; i = parent[i]
                return i
            for own in edge_owner.values():
                for j in own[1:]:
                    ra, rb = find(own[0]), find(j)
                    if ra != rb: parent[ra] = rb
            comps = {}
            for i in ids: comps.setdefault(find(i), []).append(i)
            for comp in comps.values():
                dir_edges = {}
                for i in comp:
                    f = self.F[i][0]
                    for k in range(len(f)): dir_edges[(f[k], f[(k+1) % len(f)])] = dir_edges.get((f[k], f[(k+1) % len(f)]), 0) + 1
                bnd = [e for e in dir_edges if (e[1], e[0]) not in dir_edges]
                nxt = {}
                for a, b in bnd: nxt.setdefault(a, []).append(b)
                loops, used = [], set()
                for a, b in bnd:
                    if (a, b) in used: continue
                    loop = [a]; cur = (a, b)
                    while cur not in used:
                        used.add(cur); loop.append(cur[1])
                        cands = [x for x in nxt.get(cur[1], []) if (cur[1], x) not in used]
                        if not cands: break
                        cur = (cur[1], cands[0])
                    if loop[0] == loop[-1]: loop.pop()
                    if len(loop) >= 3: loops.append(loop)
                n = np.asarray(self.F[comp[0]][1])
                areas = [_loop_area(V, l, n) for l in loops]
                if not loops: continue
                oi = int(np.argmax(areas))
                outer = loops[oi]; inner = [l for i, l in enumerate(loops) if i != oi]
                faces.append((outer, inner, n))
        return faces


def _loop_area(V, loop, n):
    s = np.zeros(3)
    for i in range(len(loop)): s += np.cross(V[loop[i]], V[loop[(i+1) % len(loop)]])
    return 0.5*float(np.dot(s, n))

def _triangulate(V, f, n):
    """Ear clipping in the polygon's plane (handles collinear T-junction vertices)."""
    if len(f) == 3: return [tuple(f)]
    u = np.cross(n, [1, 0, 0] if abs(n[0]) < .9 else [0, 1, 0]); u /= np.linalg.norm(u); v = np.cross(n, u)
    pts = {i: (float(np.dot(V[i], u)), float(np.dot(V[i], v))) for i in f}
    idx = list(f); tris = []
    def area2(a, b, c):
        (ax, ay), (bx, by), (cx, cy) = pts[a], pts[b], pts[c]
        return (bx-ax)*(cy-ay) - (by-ay)*(cx-ax)
    guard = 0
    while len(idx) > 3 and guard < 10000:
        guard += 1; done = False
        for i in range(len(idx)):
            a, b, c = idx[i-1], idx[i], idx[(i+1) % len(idx)]
            if area2(a, b, c) <= 1e-12: continue
            ok = True
            for d in idx:
                if d in (a, b, c): continue
                if area2(a, b, d) >= -1e-12 and area2(b, c, d) >= -1e-12 and area2(c, a, d) >= -1e-12:
                    # point inside or on the ear: allowed only if it lies on edge a-c? reject to stay safe
                    ok = False; break
            if ok:
                tris.append((a, b, c)); idx.pop(i); done = True; break
        if not done:
            # fall back: remove a collinear vertex as a zero-area sliver handled by neighbour triangle
            for i in range(len(idx)):
                a, b, c = idx[i-1], idx[i], idx[(i+1) % len(idx)]
                if abs(area2(a, b, c)) <= 1e-12:
                    tris.append((a, b, c)); idx.pop(i); done = True; break
        if not done: break
    if len(idx) == 3: tris.append(tuple(idx))
    return tris

# ------------------------------------------------------------------ writers

def write_stl(mesh, path, name="part"):
    V = mesh.V; tris = mesh.triangles()
    with open(path, "wb") as fh:
        fh.write(name.encode()[:80].ljust(80, b" ")); fh.write(struct.pack("<I", len(tris)))
        for a, b, c in tris:
            n = np.cross(V[b]-V[a], V[c]-V[a]); l = np.linalg.norm(n); n = n/l if l > 0 else n
            fh.write(struct.pack("<12fH", *n, *V[a], *V[b], *V[c], 0))
    return len(tris)

def _r(x):
    s = f"{x:.6f}".rstrip("0")
    if s.endswith("."): s += "0"
    if s in ("-0.0", "-0."): s = "0.0"
    return s

def write_step(parts, path, product="AgriMesh head"):
    """parts: list of (name, Mesh). Writes one AP214 file with one manifold solid per part."""
    out, n = [], [0]
    def E(txt):
        n[0] += 1; out.append(f"#{n[0]}={txt};"); return n[0]
    app = E("APPLICATION_CONTEXT('core data for automotive mechanical design processes')")
    E(f"APPLICATION_PROTOCOL_DEFINITION('international standard','automotive_design',2000,#{app})")
    pctx = E(f"PRODUCT_CONTEXT('',#{app},'mechanical')")
    prod = E(f"PRODUCT('{product}','{product}','',(#{pctx}))")
    E(f"PRODUCT_RELATED_PRODUCT_CATEGORY('part',$,(#{prod}))")
    pdf = E(f"PRODUCT_DEFINITION_FORMATION('','',#{prod})")
    pdc = E(f"PRODUCT_DEFINITION_CONTEXT('part definition',#{app},'design')")
    pd = E(f"PRODUCT_DEFINITION('design','',#{pdf},#{pdc})")
    pds = E(f"PRODUCT_DEFINITION_SHAPE('','',#{pd})")
    lu = E("(LENGTH_UNIT()NAMED_UNIT(*)SI_UNIT(.MILLI.,.METRE.))")
    au = E("(NAMED_UNIT(*)PLANE_ANGLE_UNIT()SI_UNIT($,.RADIAN.))")
    su = E("(NAMED_UNIT(*)SI_UNIT($,.STERADIAN.)SOLID_ANGLE_UNIT())")
    unc = E(f"UNCERTAINTY_MEASURE_WITH_UNIT(LENGTH_MEASURE(1.E-04),#{lu},'distance_accuracy_value','confusion accuracy')")
    ctx = E(f"(GEOMETRIC_REPRESENTATION_CONTEXT(3)GLOBAL_UNCERTAINTY_ASSIGNED_CONTEXT((#{unc}))GLOBAL_UNIT_ASSIGNED_CONTEXT((#{lu},#{au},#{su}))REPRESENTATION_CONTEXT('Context #1','3D Context with UNIT and UNCERTAINTY'))")
    o = E("CARTESIAN_POINT('',(0.0,0.0,0.0))"); dz = E("DIRECTION('',(0.0,0.0,1.0))"); dx = E("DIRECTION('',(1.0,0.0,0.0))")
    ax0 = E(f"AXIS2_PLACEMENT_3D('',#{o},#{dz},#{dx})")
    solids = []
    for name, mesh in parts:
        V = mesh.V
        cp = {}; vp = {}
        def vert(i):
            if i not in vp:
                x, y, z = V[i]
                cp[i] = E(f"CARTESIAN_POINT('',({_r(x)},{_r(y)},{_r(z)}))")
                vp[i] = E(f"VERTEX_POINT('',#{cp[i]})")
            return vp[i]
        edges = {}
        def edge(a, b):
            key = (min(a, b), max(a, b))
            if key not in edges:
                p, q = V[key[0]], V[key[1]]; d = q - p; L = float(np.linalg.norm(d)); d = d/L
                dr = E(f"DIRECTION('',({_r(d[0])},{_r(d[1])},{_r(d[2])}))")
                vec = E(f"VECTOR('',#{dr},{_r(L)})")
                vert(key[0]); vert(key[1])
                ln = E(f"LINE('',#{cp[key[0]]},#{vec})")
                edges[key] = E(f"EDGE_CURVE('',#{vp[key[0]]},#{vp[key[1]]},#{ln},.T.)")
            return edges[key], (a, b) == key
        face_ids = []
        for outer, inners, nrm in mesh.merged_faces():
            bounds = []
            for li, loop in enumerate([outer] + inners):
                oes = []
                for k in range(len(loop)):
                    ec, same = edge(loop[k], loop[(k+1) % len(loop)])
                    oes.append(E(f"ORIENTED_EDGE('',*,*,#{ec},{'.T.' if same else '.F.'})"))
                el = E(f"EDGE_LOOP('',({','.join('#'+str(x) for x in oes)}))")
                bounds.append(E(f"{'FACE_OUTER_BOUND' if li == 0 else 'FACE_BOUND'}('',#{el},.T.)"))
            p0 = V[outer[0]]
            ref = np.cross(nrm, [1, 0, 0] if abs(nrm[0]) < .9 else [0, 1, 0]); ref /= np.linalg.norm(ref)
            pc = E(f"CARTESIAN_POINT('',({_r(p0[0])},{_r(p0[1])},{_r(p0[2])}))")
            pn = E(f"DIRECTION('',({_r(nrm[0])},{_r(nrm[1])},{_r(nrm[2])}))")
            pr = E(f"DIRECTION('',({_r(ref[0])},{_r(ref[1])},{_r(ref[2])}))")
            pl = E(f"PLANE('',#{E(f'AXIS2_PLACEMENT_3D({chr(39)}{chr(39)},#{pc},#{pn},#{pr})')})")
            face_ids.append(E(f"ADVANCED_FACE('',({','.join('#'+str(b) for b in bounds)}),#{pl},.T.)"))
        sh = E(f"CLOSED_SHELL('',({','.join('#'+str(f) for f in face_ids)}))")
        solids.append(E(f"MANIFOLD_SOLID_BREP('{name}',#{sh})"))
    rep = E(f"ADVANCED_BREP_SHAPE_REPRESENTATION('{product}',(#{ax0},{','.join('#'+str(s) for s in solids)}),#{ctx})")
    E(f"SHAPE_DEFINITION_REPRESENTATION(#{pds},#{rep})")
    stamp = datetime.datetime(2026, 11, 3, 12, 0, 0).isoformat()
    head = ["ISO-10303-21;", "HEADER;", f"FILE_DESCRIPTION(('{product}'),'2;1');",
            f"FILE_NAME('{path.split('/')[-1]}','{stamp}',('AgriMesh team'),(''),'agrimesh-csg','agrimesh-csg','');",
            "FILE_SCHEMA(('AUTOMOTIVE_DESIGN { 1 0 10303 214 1 1 1 1 }'));", "ENDSEC;", "DATA;"]
    with open(path, "w") as fh:
        fh.write("\n".join(head + out + ["ENDSEC;", "END-ISO-10303-21;"]) + "\n")
    return n[0]
