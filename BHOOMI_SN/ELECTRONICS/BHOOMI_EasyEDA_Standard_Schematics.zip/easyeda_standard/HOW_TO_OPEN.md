# BHOOMI schematics: EasyEDA Standard source files

These are EasyEDA **Standard** files (`.json`), not EasyEDA Pro files.

| File | What it is |
|---|---|
| `BHOOMI_SoilNode_P1_EasyEDA.json` | The prototype board as soldered (1 sheet) |
| `PRO_Sheet1_Power_EasyEDA.json` | Product concept, sheet 1: power |
| `PRO_Sheet2_MCU_Radio_EasyEDA.json` | Product concept, sheet 2: MCU and radio |
| `PRO_Sheet3_Sensors_EasyEDA.json` | Product concept, sheet 3: sensors |
| `PRO_AllSheets_Project_EasyEDA.json` | All three product sheets in one file |
| `*.png` | Pictures drawn from these same JSON files |
| `*_netlist.csv` | The connections read back out of the JSON files (check list) |

## Open in EasyEDA Standard (easyeda.com/editor)
1. Go to **File → Open → EasyEDA Source…** and pick a `.json` file. The sheet opens as a new, unsaved schematic.
2. Press **Ctrl+S** to save it into your project.
3. For the product, open each `PRO_Sheet…` file and save them all into the **same** project. Net labels with the same name (for example `I2C1_SDA`) then connect across the three sheets.
4. If a sheet opens off-screen, press **K** (fit to view).

## Good to know
- **Parts are generic drawn symbols**, not LCSC library parts. Before converting to a PCB, assign each part a footprint in **Properties → Package** (ESP32-DevKitC-32 38-pin, Ra-02 module, 0805 resistors and so on), or swap the symbol for an LCSC part.
- **Connections use EasyEDA net labels and GND / +3V3 flags.** The pin numbers on the modules (VCC, AOUT …) follow pin names. Check each module's silkscreen before making a PCB.
- **KiCad 8 and newer** can import the same files with **File → Import → Non-KiCad Schematic → EasyEDA Std**.
- **Single-pin nets on the product sheets are expected:**
  - `PG_3V3`, `UART0_TX` and `UART0_RX` are test points.
  - Each product sheet on its own has signals that continue on the other sheets.
