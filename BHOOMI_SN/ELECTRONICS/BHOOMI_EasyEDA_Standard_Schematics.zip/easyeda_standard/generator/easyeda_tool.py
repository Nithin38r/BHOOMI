"""Render an EasyEDA Standard schematic JSON to PNG and extract its netlist (independent check of the file).
usage: python3 easyeda_tool.py sheet.json out.png out_netlist.csv"""
import json, re, sys, csv, math
from collections import defaultdict
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Ellipse, Arc, Circle

def nums(s):
    return [float(v) for v in re.findall(r"-?\d+(?:\.\d+)?", s)]

def pts_of(s):
    v = nums(s)
    return list(zip(v[0::2], v[1::2]))

class Doc:
    def __init__(self, path):
        d = json.load(open(path, encoding="utf-8"))
        if "schematics" in d:
            d = json.loads(d["schematics"][0]["dataStr"])
        self.d = d
        self.wires, self.junctions, self.ncs, self.labels, self.flags, self.parts, self.graphics = [], [], [], [], [], [], []
        for sh in d["shape"]:
            self.parse(sh, None)

    def parse(self, sh, part):
        if sh.startswith("LIB~"):
            subs = sh.split("#@$")
            head = subs[0].split("~")
            para = head[3].split("`")
            pm = dict(zip(para[0::2], para[1::2]))
            p = {"ref": pm.get("pre", "?"), "value": pm.get("name", ""), "pins": [], "gfx": []}
            self.parts.append(p)
            for s in subs[1:]:
                self.parse(s, p)
            return
        t = sh.split("~")[0]
        if t == "P" and part is not None:
            seg = sh.split("^^")
            cfg = seg[0].split("~"); dot = seg[1].split("~"); path = seg[2].split("~")
            name = seg[3].split("~"); num = seg[4].split("~")
            part["pins"].append({"num": num[4] or cfg[3], "name": name[4], "dot": (float(dot[0]), float(dot[1])), "path": path[0],
                                 "showname": name[0] == "1", "name_xy": (float(name[1]), float(name[2])), "name_anchor": name[5],
                                 "num_xy": (float(num[1]), float(num[2]))})
        elif t == "W":
            a = sh.split("~"); self.wires.append(pts_of(a[1]))
        elif t == "J":
            a = sh.split("~"); self.junctions.append((float(a[1]), float(a[2])))
        elif t == "O":
            a = sh.split("~"); self.ncs.append((float(a[1]), float(a[2])))
        elif t == "N":
            a = sh.split("~")
            self.labels.append({"xy": (float(a[1]), float(a[2])), "name": a[5], "anchor": a[7], "txy": (float(a[8]), float(a[9]))})
        elif t == "F":
            seg = sh.split("^^"); cfg = seg[0].split("~"); anc = seg[1].split("~"); txt = seg[2].split("~")
            self.flags.append({"kind": cfg[1], "xy": (float(anc[0]), float(anc[1])), "name": txt[0], "txy": (float(txt[2]), float(txt[3])),
                               "anchor": txt[5], "gfx": seg[3:]})
        else:
            (part["gfx"] if part is not None else self.graphics).append(sh)

    # ---------------- netlist ----------------
    def netlist(self):
        par = {}
        def f(x):
            par.setdefault(x, x)
            while par[x] != x:
                par[x] = par[par[x]]; x = par[x]
            return x
        def un(a, b): par[f(a)] = f(b)
        R = lambda p: (round(p[0], 2), round(p[1], 2))
        segs = []
        for w in self.wires:
            for a, b in zip(w, w[1:]):
                un(("pt",) + R(a), ("pt",) + R(b)); segs.append((R(a), R(b)))
        def on_seg(p, a, b):
            if a[0] == b[0] == p[0]: return min(a[1], b[1]) - 0.01 <= p[1] <= max(a[1], b[1]) + 0.01
            if a[1] == b[1] == p[1]: return min(a[0], b[0]) - 0.01 <= p[0] <= max(a[0], b[0]) + 0.01
            return False
        def attach(node, p):
            p = R(p); un(node, ("pt",) + p)
            for a, b in segs:
                if on_seg(p, a, b): un(node, ("pt",) + a)
        for w in self.wires:                       # wire ends landing on other wires (T-joins)
            for p in (w[0], w[-1]): attach(("pt",) + R(p), p)
        pins = []
        for part in self.parts:
            for pn in part["pins"]:
                node = ("pin", part["ref"], pn["num"], pn["name"]); pins.append((node, pn)); attach(node, pn["dot"])
        for lb in self.labels:
            attach(("label", lb["name"]), lb["xy"]); un(("label", lb["name"]), ("net", lb["name"]))
        for fl in self.flags:
            attach(("flag", fl["name"], fl["xy"]), fl["xy"]); un(("flag", fl["name"], fl["xy"]), ("net", fl["name"]))
        nc = {R(p) for p in self.ncs}
        nets = defaultdict(list); names = defaultdict(set)
        for node in list(par):
            r = f(node)
            if node[0] == "pin": nets[r].append(node)
            if node[0] == "net": names[r].add(node[1])
        out, problems, auto = [], [], 0
        for r, members in nets.items():
            nm = "/".join(sorted(names[r])) if names[r] else None
            if not nm:
                auto += 1; nm = "N$%d" % auto
            for m in members: out.append((nm, m[1], m[2], m[3]))
            if len(members) == 1:
                node = members[0]
                pn = [p for n, p in pins if n == node][0]
                if R(pn["dot"]) not in nc and not names[r]:
                    problems.append("unconnected pin %s.%s (%s)" % node[1:4][::1] if False else "unconnected pin %s pin %s (%s)" % (node[1], node[2], node[3]))
        single_named = [n for r, n in names.items() if len(nets.get(r, [])) < 2 and n]
        for n in single_named:
            problems.append("net %s has %d pin(s)" % ("/".join(sorted(n)), len(nets.get(next(k for k, v in names.items() if v == n), []))))
        return sorted(out), problems

    # ---------------- render ----------------
    def render(self, out):
        W, H = self.d.get("BBox", {}).get("width", 1654), self.d.get("BBox", {}).get("height", 1169)
        fig = plt.figure(figsize=(W / 100, H / 100), dpi=220); ax = fig.add_axes([0, 0, 1, 1])
        ax.set_xlim(0, W); ax.set_ylim(H, 0); ax.axis("off"); fig.patch.set_facecolor("white")
        k = (W / 100) * 72 / W
        def text(x, y, s, pt, color, anchor):
            ha = {"start": "left", "middle": "center", "end": "right"}.get(anchor, "left")
            ax.text(x, y, s, fontsize=pt * k * 1.05, color=color, ha=ha, va="baseline", family="DejaVu Sans", zorder=6)
        def gfx(sh, color_override=None):
            a = sh.split("~"); t = a[0]
            if t == "R":
                x, y, w, h = float(a[1]), float(a[2]), float(a[5]), float(a[6])
                ls = (0, (5, 3)) if a[9] == "1" else "-"
                fc = a[10] if a[10] not in ("none", "") else "none"
                ax.add_patch(Rectangle((x, y), w, h, ec=a[7], fc=fc if fc != "#FFFFFF" else "#FFFFF5", lw=0.6, ls=ls, zorder=2))
            elif t == "PL":
                p = pts_of(a[1]); ax.plot(*zip(*p), color=color_override or a[2], lw=0.7, zorder=4)
            elif t == "E":
                ax.add_patch(Ellipse((float(a[1]), float(a[2])), 2 * float(a[3]), 2 * float(a[4]), ec=a[5], fc="white", lw=0.6, zorder=4))
            elif t == "A":
                v = nums(a[1]); x0, y0, rx, ry, x1, y1 = v[0], v[1], v[2], v[3], v[7], v[8]
                ax.add_patch(Arc(((x0 + x1) / 2, y0), abs(x1 - x0), 2 * ry, theta1=180, theta2=360, ec=a[3], lw=0.7, zorder=4))
            elif t == "T":
                pt = float(re.sub("[^0-9.]", "", a[7]) or 7)
                text(float(a[2]), float(a[3]), a[12], pt, a[5], a[14])
        for sh in self.graphics: gfx(sh)
        for part in self.parts:
            for sh in part["gfx"]: gfx(sh)
            for pn in part["pins"]:
                v = nums(pn["path"]); x, y, d = v[0], v[1], v[2]
                x2, y2 = (x + d, y) if " h " in pn["path"] else (x, y + d)
                ax.plot([x, x2], [y, y2], color="#880000", lw=0.7, zorder=4)
                if pn["showname"]: text(pn["name_xy"][0], pn["name_xy"][1], pn["name"], 6, "#0000FF", pn["name_anchor"])
                if pn["num"] and not pn["num"].startswith(("+", "-")) and pn["showname"]:
                    text(pn["num_xy"][0], pn["num_xy"][1], pn["num"], 4.5, "#880000", "middle")
        for w in self.wires: ax.plot(*zip(*w), color="#008800", lw=0.8, zorder=3)
        for j in self.junctions: ax.add_patch(Circle(j, 1.8, color="#CC0000", zorder=5))
        for x, y in self.ncs:
            ax.plot([x - 3, x + 3], [y - 3, y + 3], color="#33cc33", lw=0.7); ax.plot([x - 3, x + 3], [y + 3, y - 3], color="#33cc33", lw=0.7)
        for lb in self.labels:
            text(lb["txy"][0], lb["txy"][1], lb["name"], 6.5, "#0000FF", lb["anchor"])
        for fl in self.flags:
            for g in fl["gfx"]: gfx(g, "#000000")
            text(fl["txy"][0], fl["txy"][1] + (2 if "gnD" in fl["kind"] else 0), fl["name"], 6.5, "#000000", fl["anchor"])
        fig.savefig(out, facecolor="white"); plt.close(fig)


if __name__ == "__main__":
    d = Doc(sys.argv[1])
    d.render(sys.argv[2])
    rows, problems = d.netlist()
    with open(sys.argv[3], "w", newline="") as f:
        w = csv.writer(f); w.writerow(["net", "ref", "pin", "pin_name"]); w.writerows(rows)
    print("parts", len(d.parts), "wires", len(d.wires), "labels", len(d.labels), "flags", len(d.flags), "nets", len({r[0] for r in rows}))
    for p in problems: print("  CHECK:", p)
